#include <Arduino.h>
/*
  Brendan Crawford 
  000832017

  I, Brendan Crawford, student number 000832017, claim this is no ones work but my own.
  I have not shared my work with anyone else.
*/

void setup() {
  // put your setup code here, to run once:

  // configure the USB serial monitor 
  Serial.begin(115200); 
}

void loop() {
  // put your main code here, to run repeatedly:

  int iVal; 
  float temp;
  String judgement;
 
  // read digitized value from the D1 Mini's A/D convertor 
  iVal = analogRead(A0); 

  temp = map(iVal, 0, 1023, 0, 5000);

  temp = temp / 100;

  if (temp < 10) {
    judgement = "Cold!";
  }
  else if (temp >= 10 && temp < 15) {
    judgement = "Cool";
  }
  else if (temp >= 15 && temp < 25) {
    judgement = "Perfect";
  }
  else if (temp >= 25 && temp < 30) {
    judgement = "Warm";
  }
  else if (temp >= 30 && temp < 35) {
    judgement = "Hot";
  }
  else if (temp >= 35) {
    judgement = "Too Hot!";
  }


 
  // print value to the USB port 
  Serial.println("Digitized Value of " + String(iVal) + " is equivalent to an Analog voltage = " + String(temp) + "C which is " + judgement); 
 
  // wait 0.5 seconds (500 ms) 
  delay(2000); 
}